# Simple Smart Contract — SimpleStorage

A Solidity smart contract demonstrating core Ethereum development concepts.
Deployed and tested on the **Sepolia testnet** using Remix IDE and Hardhat.

## Contract: SimpleStorage.sol

### Features

| Feature | Description |
|---------|-------------|
| Global number storage | Any user can read/write a shared number |
| Personal number storage | Each address has its own number slot |
| Owner-gated message | Only the deployer can update the global message |
| Personal messages | Any user stores their own message |
| ETH deposits | `receive()` accepts ETH sent directly to contract |
| Owner withdrawal | Deployer can withdraw all held ETH |
| Events | All state changes emit on-chain events |
| Access control | `onlyOwner` modifier restricts admin functions |

### Solidity Concepts Demonstrated

- **State variables** — `uint256`, `string`, `address`, `mapping`
- **Visibility** — `public`, `private`, `external`, `view`
- **Constructor** — initialises owner, number, and message on deploy
- **Modifiers** — `onlyOwner`, `nonEmptyString` for reusable guards
- **Events** — `NumberUpdated`, `MessageStored`, `FundsWithdrawn`, etc.
- **require()** — input validation with descriptive error messages
- **payable** — `receive()` fallback for ETH acceptance
- **call{value}** — safe ETH transfer pattern

## Project Structure

```
simple-smart-contract/
├── SimpleStorage.sol          # Main contract
├── SimpleStorage.test.js      # Hardhat test suite (22 tests)
├── hardhat.config.js          # Hardhat + Sepolia config
└── README.md
```

## Setup & Deployment

### Prerequisites
```bash
npm install --save-dev hardhat @nomicfoundation/hardhat-toolbox
```

### Compile
```bash
npx hardhat compile
```

### Test (local Hardhat network)
```bash
npx hardhat test
```

### Deploy to Sepolia Testnet
```bash
npx hardhat run scripts/deploy.js --network sepolia
```

### Remix IDE (Quick Start)
1. Open https://remix.ethereum.org
2. Create `SimpleStorage.sol` and paste the contract
3. Compile with Solidity `^0.8.20`
4. Under *Deploy & Run*: select **Injected Provider - MetaMask** and connect to Sepolia
5. Enter constructor args: `42, "Hello Blockchain"` → Deploy
6. Interact with read/write functions in the Remix UI

## Function Reference

| Function | Visibility | Access | Description |
|----------|------------|--------|-------------|
| `setNumber(uint256)` | external | Anyone | Set global stored number |
| `getNumber()` | external view | Anyone | Read global stored number |
| `storeMyNumber(uint256)` | external | Anyone | Store your own number |
| `getUserNumber(address)` | external view | Anyone | Read any user's number |
| `setMessage(string)` | external | Owner only | Update global message |
| `getMessage()` | external view | Anyone | Read global message |
| `storeMyMessage(string)` | external | Anyone | Store your own message |
| `getMyMessage()` | external view | Caller | Read your own message |
| `withdraw()` | external | Owner only | Withdraw all ETH |
| `getContractBalance()` | external view | Anyone | ETH balance of contract |
| `receive()` | external payable | Anyone | Accept ETH deposits |

## Security Considerations

| Vulnerability | How Addressed |
|---------------|---------------|
| Unauthorized access | `onlyOwner` modifier on admin functions |
| Reentrancy (withdraw) | Effects-before-interactions pattern; balance zeroed before transfer |
| Empty string input | `nonEmptyString` modifier with `require` |
| Failed ETH transfer | Return value of `.call{value}()` checked with `require(success)` |
| Integer overflow | Solidity 0.8+ has built-in overflow checks |

## Testnet Deployment

- **Network**: Sepolia (Chain ID: 11155111)
- **Compiler**: Solidity 0.8.20
- **Tools**: Remix IDE, MetaMask, Hardhat
- **Faucet**: https://sepoliafaucet.com

> Get free Sepolia ETH from the faucet to cover gas costs during testing.
