// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title SimpleStorage
 * @author Blockchain Internship - Project 2
 * @notice A simple smart contract demonstrating core Solidity concepts:
 *         state variables, mappings, events, modifiers, and access control.
 *
 * @dev Deployed and tested on Sepolia testnet via Remix IDE.
 *      Key concepts covered:
 *        - State variables (uint, string, mapping, address)
 *        - Public/private visibility
 *        - Events and emit
 *        - Custom modifiers (onlyOwner)
 *        - require() for input validation
 *        - Payable functions and ETH handling
 */
contract SimpleStorage {

    // ─────────────────────────────────────────────
    //  State Variables
    // ─────────────────────────────────────────────

    address public owner;
    uint256 private storedNumber;
    string  private storedMessage;

    mapping(address => uint256) public userNumbers;
    mapping(address => string)  private userMessages;

    uint256 public totalUpdates;
    uint256 public contractBalance;

    // ─────────────────────────────────────────────
    //  Events
    // ─────────────────────────────────────────────

    /// @notice Emitted when the global number is updated
    event NumberUpdated(address indexed updater, uint256 oldValue, uint256 newValue);

    /// @notice Emitted when a user stores a personal number
    event UserNumberStored(address indexed user, uint256 value);

    /// @notice Emitted when a message is stored
    event MessageStored(address indexed sender, string message);

    /// @notice Emitted when the owner withdraws ETH
    event FundsWithdrawn(address indexed to, uint256 amount);

    // ─────────────────────────────────────────────
    //  Modifiers
    // ─────────────────────────────────────────────

    /// @dev Restricts function access to the contract deployer
    modifier onlyOwner() {
        require(msg.sender == owner, "SimpleStorage: caller is not the owner");
        _;
    }

    /// @dev Ensures a string is not empty
    modifier nonEmptyString(string memory _str) {
        require(bytes(_str).length > 0, "SimpleStorage: string cannot be empty");
        _;
    }

    // ─────────────────────────────────────────────
    //  Constructor
    // ─────────────────────────────────────────────

    /**
     * @notice Sets the deploying address as owner and initialises default values.
     * @param _initialNumber The starting value for storedNumber
     * @param _initialMessage The starting message
     */
    constructor(uint256 _initialNumber, string memory _initialMessage) {
        owner = msg.sender;
        storedNumber  = _initialNumber;
        storedMessage = _initialMessage;
        totalUpdates  = 0;
    }

    // ─────────────────────────────────────────────
    //  Write Functions
    // ─────────────────────────────────────────────

    /**
     * @notice Update the global stored number (any caller).
     * @param _number The new value to store
     */
    function setNumber(uint256 _number) external {
        uint256 old = storedNumber;
        storedNumber = _number;
        totalUpdates += 1;
        emit NumberUpdated(msg.sender, old, _number);
    }

    /**
     * @notice Store a personal number tied to the caller's address.
     * @param _number The value to associate with msg.sender
     */
    function storeMyNumber(uint256 _number) external {
        userNumbers[msg.sender] = _number;
        emit UserNumberStored(msg.sender, _number);
    }

    /**
     * @notice Store a message (global, owner only).
     * @param _message The message string to store
     */
    function setMessage(string memory _message)
        external
        onlyOwner
        nonEmptyString(_message)
    {
        storedMessage = _message;
        emit MessageStored(msg.sender, _message);
    }

    /**
     * @notice Store a personal message tied to the caller's address.
     * @param _message The message to store
     */
    function storeMyMessage(string memory _message)
        external
        nonEmptyString(_message)
    {
        userMessages[msg.sender] = _message;
        emit MessageStored(msg.sender, _message);
    }

    /**
     * @notice Accept ETH deposits into the contract.
     */
    receive() external payable {
        contractBalance += msg.value;
    }

    /**
     * @notice Withdraw all ETH from the contract (owner only).
     */
    function withdraw() external onlyOwner {
        uint256 amount = address(this).balance;
        require(amount > 0, "SimpleStorage: no funds to withdraw");
        contractBalance = 0;
        (bool success, ) = payable(owner).call{value: amount}("");
        require(success, "SimpleStorage: withdrawal failed");
        emit FundsWithdrawn(owner, amount);
    }

    // ─────────────────────────────────────────────
    //  Read Functions (view = no gas when called externally)
    // ─────────────────────────────────────────────

    /// @notice Returns the current global stored number
    function getNumber() external view returns (uint256) {
        return storedNumber;
    }

    /// @notice Returns the current global stored message
    function getMessage() external view returns (string memory) {
        return storedMessage;
    }

    /// @notice Returns the personal message for a given address
    function getMyMessage() external view returns (string memory) {
        return userMessages[msg.sender];
    }

    /// @notice Returns the personal number for any queried address
    function getUserNumber(address _user) external view returns (uint256) {
        return userNumbers[_user];
    }

    /// @notice Returns the ETH balance held by this contract
    function getContractBalance() external view returns (uint256) {
        return address(this).balance;
    }
}
