# Basic Blockchain Implementation

A simple proof-of-work blockchain built in Python demonstrating core blockchain mechanics:
SHA-256 hashing, block structure, chain validation, and tamper detection.

## Features

- **Block Structure** — index, timestamp, transactions, previous_hash, nonce, hash
- **SHA-256 Hashing** — cryptographic integrity for every block
- **Proof of Work Mining** — adjustable difficulty (leading zeros)
- **Transaction Pool** — pending transactions batched into blocks
- **Miner Rewards** — 1 coin reward per mined block
- **Chain Validation** — detects hash mismatches and broken chain links
- **Balance Lookup** — scan full chain to compute any address balance
- **Tamper Detection** — any modification to historical data is caught

## Project Structure

```
basic-blockchain/
├── blockchain.py      # Core Block and Blockchain classes
├── test_blockchain.py # 14 unit tests (all passing)
└── README.md
```

## Quick Start

```bash
# Run the demo
python blockchain.py

# Run tests
python test_blockchain.py
```

No external dependencies — standard library only (`hashlib`, `json`, `time`).

## How It Works

### Block Structure
Each block contains:
- `index` — position in the chain
- `timestamp` — Unix time of creation
- `transactions` — list of sender/receiver/amount records
- `previous_hash` — links to the prior block (SHA-256)
- `nonce` — counter incremented during mining
- `hash` — SHA-256 of all the above fields

### Proof of Work
Mining increments the nonce until the block's hash starts with N zeros (default: 4).
This makes block creation computationally expensive, securing the chain against cheap rewrites.

```
Target: 0000xxxxxxxxxxxx...
Attempts: ~50,000 average per block at difficulty 4
```

### Chain Validation
`is_chain_valid()` checks three things per block:
1. Stored hash matches recomputed hash (detects data tampering)
2. `previous_hash` matches the actual hash of the prior block (detects insertion/deletion)
3. Hash satisfies mining difficulty (detects hash spoofing)

### Tamper Detection Demo
```
Original chain  → VALID ✓
Modify amount   → INVALID ✗ (hash mismatch detected)
Modify prev_hash→ INVALID ✗ (chain link broken)
```

## Security Considerations

| Risk | Mitigation in this implementation |
|------|-----------------------------------|
| Data tampering | SHA-256 hash of every block |
| Block insertion | `previous_hash` chain linkage |
| Hash spoofing | Proof-of-Work difficulty check |
| 51% attack | Conceptually present; requires majority compute power |

> **Note:** This is a learning implementation. It does not include networking (P2P), 
> persistent storage, or a full consensus mechanism. For production use, see 
> Ethereum, Hyperledger, or Bitcoin Core.

## Concepts Demonstrated

- **Immutability**: Changing any past block breaks all subsequent hashes
- **Decentralization**: Each participant could hold a full copy of this chain
- **Transparency**: All transactions are visible to chain validators
- **Incentive**: Miners earn rewards, motivating honest participation
