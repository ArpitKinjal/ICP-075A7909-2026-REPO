"""
Unit tests for the basic blockchain implementation.
Run with: python test_blockchain.py
"""

import unittest
import time
from blockchain import Block, Blockchain


class TestBlock(unittest.TestCase):

    def test_block_creation(self):
        block = Block(index=1, transactions=[{"sender": "A", "receiver": "B", "amount": 10}], previous_hash="abc")
        self.assertEqual(block.index, 1)
        self.assertIsNotNone(block.hash)
        self.assertEqual(block.previous_hash, "abc")

    def test_block_hash_changes_on_tamper(self):
        block = Block(index=1, transactions=[], previous_hash="abc")
        original_hash = block.hash
        block.transactions = [{"sender": "Hacker", "receiver": "Hacker", "amount": 9999}]
        new_hash = block.compute_hash()
        self.assertNotEqual(original_hash, new_hash)

    def test_block_to_dict(self):
        block = Block(index=0, transactions=[], previous_hash="0" * 64)
        d = block.to_dict()
        self.assertIn("hash", d)
        self.assertIn("index", d)
        self.assertIn("nonce", d)


class TestBlockchain(unittest.TestCase):

    def setUp(self):
        self.bc = Blockchain()

    def test_genesis_block_created(self):
        self.assertEqual(len(self.bc.chain), 1)
        self.assertEqual(self.bc.chain[0].index, 0)
        self.assertEqual(self.bc.chain[0].previous_hash, "0" * 64)

    def test_add_transaction(self):
        self.bc.add_transaction("Alice", "Bob", 50)
        self.assertEqual(len(self.bc.pending_transactions), 1)
        self.assertEqual(self.bc.pending_transactions[0]["amount"], 50)

    def test_mine_block_clears_pending(self):
        self.bc.add_transaction("Alice", "Bob", 50)
        self.bc.mine_block("Miner1")
        self.assertEqual(len(self.bc.pending_transactions), 0)

    def test_mine_block_appends_to_chain(self):
        self.bc.add_transaction("Alice", "Bob", 10)
        self.bc.mine_block("Miner1")
        self.assertEqual(len(self.bc.chain), 2)

    def test_mining_difficulty_satisfied(self):
        self.bc.add_transaction("Alice", "Bob", 5)
        block = self.bc.mine_block("Miner1")
        target = "0" * Blockchain.MINING_DIFFICULTY
        self.assertTrue(block.hash.startswith(target))

    def test_chain_linkage(self):
        self.bc.add_transaction("Alice", "Bob", 10)
        self.bc.mine_block("Miner1")
        self.bc.add_transaction("Bob", "Charlie", 5)
        self.bc.mine_block("Miner2")

        self.assertEqual(self.bc.chain[2].previous_hash, self.bc.chain[1].hash)

    def test_chain_valid_after_mining(self):
        self.bc.add_transaction("Alice", "Bob", 30)
        self.bc.mine_block("Miner1")
        self.bc.add_transaction("Bob", "Charlie", 10)
        self.bc.mine_block("Miner2")
        self.assertTrue(self.bc.is_chain_valid())

    def test_tamper_detection_amount(self):
        self.bc.add_transaction("Alice", "Bob", 30)
        self.bc.mine_block("Miner1")
        # Tamper with transaction
        self.bc.chain[1].transactions[0]["amount"] = 9999
        self.assertFalse(self.bc.is_chain_valid())

    def test_tamper_detection_previous_hash(self):
        self.bc.add_transaction("Alice", "Bob", 10)
        self.bc.mine_block("Miner1")
        self.bc.chain[1].previous_hash = "fakehash"
        self.assertFalse(self.bc.is_chain_valid())

    def test_balance_calculation(self):
        self.bc.add_transaction("Alice", "Bob", 50)
        self.bc.mine_block("Miner1")
        # Miner1 earns 1 coin reward; Bob gets 50; Alice sends 50
        self.assertEqual(self.bc.get_balance("Bob"), 50.0)
        self.assertEqual(self.bc.get_balance("Miner1"), 1.0)

    def test_miner_reward_added(self):
        self.bc.mine_block("Miner1")
        block = self.bc.chain[1]
        reward_txns = [tx for tx in block.transactions if tx["receiver"] == "Miner1" and tx["sender"] == "NETWORK"]
        self.assertEqual(len(reward_txns), 1)
        self.assertEqual(reward_txns[0]["amount"], 1.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
