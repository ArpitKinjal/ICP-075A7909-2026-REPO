import hashlib
import json
import time
from typing import List, Optional


class Block:
    """Represents a single block in the blockchain."""

    def __init__(self, index: int, transactions: list, previous_hash: str, nonce: int = 0):
        self.index = index
        self.timestamp = time.time()
        self.transactions = transactions
        self.previous_hash = previous_hash
        self.nonce = nonce
        self.hash = self.compute_hash()

    def compute_hash(self) -> str:
        """Compute SHA-256 hash of the block contents."""
        block_data = {
            "index": self.index,
            "timestamp": self.timestamp,
            "transactions": self.transactions,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce,
        }
        block_string = json.dumps(block_data, sort_keys=True)
        return hashlib.sha256(block_string.encode()).hexdigest()

    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "timestamp": self.timestamp,
            "transactions": self.transactions,
            "previous_hash": self.previous_hash,
            "nonce": self.nonce,
            "hash": self.hash,
        }

    def __repr__(self):
        return (
            f"Block(index={self.index}, hash={self.hash[:12]}..., "
            f"prev={self.previous_hash[:12]}..., txns={len(self.transactions)})"
        )


class Blockchain:
    """
    A simple proof-of-work blockchain implementation.
    Features: mining, chain validation, tamper detection.
    """

    MINING_DIFFICULTY = 4  # Number of leading zeros required in hash

    def __init__(self):
        self.chain: List[Block] = []
        self.pending_transactions: list = []
        self._create_genesis_block()

    def _create_genesis_block(self):
        """Create the first block (genesis block) with no previous hash."""
        genesis = Block(index=0, transactions=[], previous_hash="0" * 64)
        self.chain.append(genesis)
        print(f"[Genesis Block Created] Hash: {genesis.hash[:20]}...")

    @property
    def last_block(self) -> Block:
        return self.chain[-1]

    def add_transaction(self, sender: str, receiver: str, amount: float):
        """Add a new transaction to the pending pool."""
        transaction = {
            "sender": sender,
            "receiver": receiver,
            "amount": amount,
            "timestamp": time.time(),
        }
        self.pending_transactions.append(transaction)
        print(f"  Transaction added: {sender} -> {receiver} : {amount} coins")

    def mine_block(self, miner_address: str) -> Block:
        """
        Mine a new block using Proof of Work.
        Reward the miner with 1 coin as mining reward.
        """
        # Add mining reward transaction
        self.pending_transactions.append({
            "sender": "NETWORK",
            "receiver": miner_address,
            "amount": 1.0,
            "timestamp": time.time(),
        })

        new_block = Block(
            index=len(self.chain),
            transactions=self.pending_transactions.copy(),
            previous_hash=self.last_block.hash,
        )

        print(f"\n[Mining Block #{new_block.index}] Difficulty: {self.MINING_DIFFICULTY}")
        new_block = self._proof_of_work(new_block)

        self.chain.append(new_block)
        self.pending_transactions = []

        print(f"[Block #{new_block.index} Mined!] Hash: {new_block.hash[:20]}... | Nonce: {new_block.nonce}")
        return new_block

    def _proof_of_work(self, block: Block) -> Block:
        """
        Increment nonce until block hash starts with required zeros.
        This simulates computational work required to add a block.
        """
        target = "0" * self.MINING_DIFFICULTY
        attempts = 0

        while not block.hash.startswith(target):
            block.nonce += 1
            block.hash = block.compute_hash()
            attempts += 1

        print(f"  Solved in {attempts} attempts")
        return block

    def is_chain_valid(self) -> bool:
        """
        Validate the entire blockchain:
        1. Each block's hash must match its computed hash.
        2. Each block's previous_hash must match the prior block's hash.
        3. Each block hash must satisfy the mining difficulty.
        """
        for i in range(1, len(self.chain)):
            current = self.chain[i]
            previous = self.chain[i - 1]

            # Check hash integrity
            if current.hash != current.compute_hash():
                print(f"  [INVALID] Block #{i} hash mismatch — data was tampered!")
                return False

            # Check chain linkage
            if current.previous_hash != previous.hash:
                print(f"  [INVALID] Block #{i} previous_hash doesn't match Block #{i-1} hash!")
                return False

            # Check proof of work
            if not current.hash.startswith("0" * self.MINING_DIFFICULTY):
                print(f"  [INVALID] Block #{i} does not satisfy mining difficulty!")
                return False

        return True

    def get_balance(self, address: str) -> float:
        """Calculate balance for a given address by scanning all transactions."""
        balance = 0.0
        for block in self.chain:
            for tx in block.transactions:
                if tx["sender"] == address:
                    balance -= tx["amount"]
                if tx["receiver"] == address:
                    balance += tx["amount"]
        return balance

    def print_chain(self):
        """Display all blocks in the chain."""
        print("\n" + "=" * 60)
        print("BLOCKCHAIN LEDGER")
        print("=" * 60)
        for block in self.chain:
            print(f"\nBlock #{block.index}")
            print(f"  Timestamp  : {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(block.timestamp))}")
            print(f"  Hash       : {block.hash}")
            print(f"  Prev Hash  : {block.previous_hash}")
            print(f"  Nonce      : {block.nonce}")
            print(f"  Transactions ({len(block.transactions)}):")
            for tx in block.transactions:
                print(f"    {tx['sender']} -> {tx['receiver']}: {tx['amount']} coins")
        print("=" * 60)


# ──────────────────────────────────────────────
# Demo / Usage
# ──────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 60)
    print("   SIMPLE BLOCKCHAIN DEMO")
    print("=" * 60)

    # Create blockchain
    bc = Blockchain()

    # Add some transactions and mine block 1
    print("\n--- Adding transactions for Block 1 ---")
    bc.add_transaction("Alice", "Bob", 50)
    bc.add_transaction("Bob", "Charlie", 20)
    bc.mine_block(miner_address="Miner1")

    # Add transactions and mine block 2
    print("\n--- Adding transactions for Block 2 ---")
    bc.add_transaction("Charlie", "Alice", 10)
    bc.add_transaction("Alice", "Dave", 5)
    bc.mine_block(miner_address="Miner2")

    # Add transactions and mine block 3
    print("\n--- Adding transactions for Block 3 ---")
    bc.add_transaction("Dave", "Bob", 3)
    bc.mine_block(miner_address="Miner1")

    # Print the chain
    bc.print_chain()

    # Validate chain
    print("\n--- Chain Validation ---")
    is_valid = bc.is_chain_valid()
    print(f"Chain is {'VALID ✓' if is_valid else 'INVALID ✗'}")

    # Show balances
    print("\n--- Account Balances ---")
    for person in ["Alice", "Bob", "Charlie", "Dave", "Miner1", "Miner2"]:
        print(f"  {person}: {bc.get_balance(person):.1f} coins")

    # Demonstrate tamper detection
    print("\n--- Tamper Detection Demo ---")
    print("Tampering with Block #1 transaction data...")
    bc.chain[1].transactions[0]["amount"] = 9999
    bc.chain[1].hash = bc.chain[1].compute_hash()  # Recalculate but chain link is broken

    is_valid = bc.is_chain_valid()
    print(f"Chain after tampering is {'VALID ✓' if is_valid else 'INVALID ✗ (tamper detected!)'}")
