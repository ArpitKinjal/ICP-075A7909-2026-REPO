// test/SimpleStorage.test.js
// Run with: npx hardhat test

const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("SimpleStorage", function () {
  let contract;
  let owner, addr1, addr2;

  // Deploy a fresh contract before each test
  beforeEach(async function () {
    [owner, addr1, addr2] = await ethers.getSigners();
    const Factory = await ethers.getContractFactory("SimpleStorage");
    contract = await Factory.deploy(42, "Hello Blockchain");
    await contract.waitForDeployment();
  });

  // ─────────────────────────────────────────────
  //  Deployment
  // ─────────────────────────────────────────────
  describe("Deployment", function () {
    it("should set the deployer as owner", async function () {
      expect(await contract.owner()).to.equal(owner.address);
    });

    it("should initialise storedNumber correctly", async function () {
      expect(await contract.getNumber()).to.equal(42n);
    });

    it("should initialise storedMessage correctly", async function () {
      expect(await contract.getMessage()).to.equal("Hello Blockchain");
    });

    it("should start with zero totalUpdates", async function () {
      expect(await contract.totalUpdates()).to.equal(0n);
    });
  });

  // ─────────────────────────────────────────────
  //  setNumber
  // ─────────────────────────────────────────────
  describe("setNumber", function () {
    it("should update storedNumber", async function () {
      await contract.setNumber(100);
      expect(await contract.getNumber()).to.equal(100n);
    });

    it("should increment totalUpdates on each call", async function () {
      await contract.setNumber(1);
      await contract.setNumber(2);
      expect(await contract.totalUpdates()).to.equal(2n);
    });

    it("should emit NumberUpdated event with correct args", async function () {
      await expect(contract.setNumber(99))
        .to.emit(contract, "NumberUpdated")
        .withArgs(owner.address, 42n, 99n);
    });

    it("should allow any address to call setNumber", async function () {
      await contract.connect(addr1).setNumber(77);
      expect(await contract.getNumber()).to.equal(77n);
    });
  });

  // ─────────────────────────────────────────────
  //  storeMyNumber
  // ─────────────────────────────────────────────
  describe("storeMyNumber", function () {
    it("should store personal number per address", async function () {
      await contract.connect(addr1).storeMyNumber(55);
      await contract.connect(addr2).storeMyNumber(88);
      expect(await contract.userNumbers(addr1.address)).to.equal(55n);
      expect(await contract.userNumbers(addr2.address)).to.equal(88n);
    });

    it("should emit UserNumberStored event", async function () {
      await expect(contract.connect(addr1).storeMyNumber(33))
        .to.emit(contract, "UserNumberStored")
        .withArgs(addr1.address, 33n);
    });
  });

  // ─────────────────────────────────────────────
  //  setMessage (owner only)
  // ─────────────────────────────────────────────
  describe("setMessage", function () {
    it("should allow owner to update message", async function () {
      await contract.setMessage("New Message");
      expect(await contract.getMessage()).to.equal("New Message");
    });

    it("should revert when non-owner calls setMessage", async function () {
      await expect(contract.connect(addr1).setMessage("Hack"))
        .to.be.revertedWith("SimpleStorage: caller is not the owner");
    });

    it("should revert on empty string", async function () {
      await expect(contract.setMessage(""))
        .to.be.revertedWith("SimpleStorage: string cannot be empty");
    });
  });

  // ─────────────────────────────────────────────
  //  storeMyMessage
  // ─────────────────────────────────────────────
  describe("storeMyMessage", function () {
    it("should store personal message per address", async function () {
      await contract.connect(addr1).storeMyMessage("Hello from addr1");
      expect(await contract.connect(addr1).getMyMessage()).to.equal("Hello from addr1");
    });

    it("should revert on empty string", async function () {
      await expect(contract.storeMyMessage(""))
        .to.be.revertedWith("SimpleStorage: string cannot be empty");
    });

    it("should isolate messages between users", async function () {
      await contract.connect(addr1).storeMyMessage("Msg A");
      await contract.connect(addr2).storeMyMessage("Msg B");
      expect(await contract.connect(addr1).getMyMessage()).to.equal("Msg A");
      expect(await contract.connect(addr2).getMyMessage()).to.equal("Msg B");
    });
  });

  // ─────────────────────────────────────────────
  //  ETH handling
  // ─────────────────────────────────────────────
  describe("ETH deposit and withdraw", function () {
    it("should accept ETH via receive()", async function () {
      await owner.sendTransaction({
        to: await contract.getAddress(),
        value: ethers.parseEther("1.0"),
      });
      expect(await contract.getContractBalance()).to.equal(ethers.parseEther("1.0"));
    });

    it("should allow owner to withdraw ETH", async function () {
      await owner.sendTransaction({
        to: await contract.getAddress(),
        value: ethers.parseEther("1.0"),
      });
      await expect(contract.withdraw()).to.changeEtherBalance(
        owner,
        ethers.parseEther("1.0")
      );
    });

    it("should revert withdraw when balance is 0", async function () {
      await expect(contract.withdraw()).to.be.revertedWith(
        "SimpleStorage: no funds to withdraw"
      );
    });

    it("should revert withdraw for non-owner", async function () {
      await owner.sendTransaction({
        to: await contract.getAddress(),
        value: ethers.parseEther("0.5"),
      });
      await expect(contract.connect(addr1).withdraw()).to.be.revertedWith(
        "SimpleStorage: caller is not the owner"
      );
    });
  });
});
